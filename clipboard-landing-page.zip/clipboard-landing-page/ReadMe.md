# Simple dynamic landing page .

**_Page responsive range frm 300 pixels to 1024 pixels._**

**_You can see which section is active by looking at the navigation bar._**

_There is a button to bring you back to the top of the page that appears and disappears automatically._

_Please review te lines from **188** to **201** in the **app.js** file._
